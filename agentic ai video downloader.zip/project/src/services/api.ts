import axios from 'axios';
import { VideoMetadata, DownloadOptions } from '../types/video';

const API_BASE_URL = 'https://api.example.com'; // Replace with your actual API URL

export const videoService = {
  async getVideoMetadata(url: string): Promise<VideoMetadata> {
    try {
      const response = await axios.get(`${API_BASE_URL}/metadata`, {
        params: { url }
      });
      return response.data;
    } catch (error) {
      throw new Error('Failed to fetch video metadata');
    }
  },

  async downloadVideo(options: DownloadOptions): Promise<string> {
    try {
      const response = await axios.post(`${API_BASE_URL}/download`, options, {
        responseType: 'blob'
      });
      return URL.createObjectURL(response.data);
    } catch (error) {
      throw new Error('Failed to download video');
    }
  }
};