export interface VideoMetadata {
  title: string;
  duration: string;
  thumbnail: string;
  formats: VideoFormat[];
}

export interface VideoFormat {
  quality: string;
  format: 'mp4' | 'mp3';
  size: string;
}

export interface DownloadOptions {
  url: string;
  format: string;
  quality: string;
}