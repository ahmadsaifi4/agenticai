import React from 'react';
import { Toaster } from 'react-hot-toast';
import Hero from './components/Hero';
import VideoDownloader from './components/VideoDownloader';
import Features from './components/Features';
import Stats from './components/Stats';
import Newsletter from './components/Newsletter';
import Footer from './components/Footer';

function App() {
  return (
    <div className="min-h-screen bg-black text-white">
      <Toaster position="top-center" />
      <header className="absolute top-0 left-0 right-0 z-50">
        <nav className="max-w-7xl mx-auto px-4 py-6">
          <div className="flex justify-between items-center">
            <div className="text-2xl font-bold text-white">Agentic AI</div>
            <div className="hidden md:flex items-center gap-8">
              <a href="#" className="text-gray-300 hover:text-white">Features</a>
              <a href="#" className="text-gray-300 hover:text-white">Docs</a>
              <a href="#" className="text-gray-300 hover:text-white">Blog</a>
              <a href="#" className="text-gray-300 hover:text-white">Contact</a>
              <button className="bg-blue-500 hover:bg-blue-600 px-6 py-2 rounded-lg text-white transition-all">
                Get Started
              </button>
            </div>
          </div>
        </nav>
      </header>

      <main>
        <Hero />
        <VideoDownloader />
        <Features />
        <Stats />
        <Newsletter />
      </main>

      <Footer />
    </div>
  );
}

export default App;