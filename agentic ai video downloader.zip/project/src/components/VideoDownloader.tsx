import React, { useState } from 'react';
import { Download, Link } from 'lucide-react';
import toast from 'react-hot-toast';

export default function VideoDownloader() {
  const [url, setUrl] = useState('');
  const [loading, setLoading] = useState(false);

  const handleDownload = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!url) {
      toast.error('Please enter a YouTube URL');
      return;
    }

    setLoading(true);
    try {
      // Here you would integrate with your backend API
      // For demo purposes, we'll show a success message
      toast.success('Download started! Check your downloads folder.');
      setUrl('');
    } catch (error) {
      toast.error('Failed to download video. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="py-24 bg-black">
      <div className="max-w-4xl mx-auto px-4">
        <div className="bg-gray-900/50 backdrop-blur-sm rounded-2xl p-12">
          <div className="text-center mb-8">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
              Download YouTube Videos
            </h2>
            <p className="text-gray-400 text-lg">
              Enter a YouTube URL to download videos in high quality
            </p>
          </div>

          <form onSubmit={handleDownload} className="max-w-2xl mx-auto">
            <div className="flex flex-col sm:flex-row gap-4">
              <div className="flex-1 relative">
                <Link className="absolute left-3 top-1/2 -translate-y-1/2 text-gray-400 w-5 h-5" />
                <input
                  type="url"
                  value={url}
                  onChange={(e) => setUrl(e.target.value)}
                  placeholder="Paste YouTube URL here..."
                  className="w-full pl-10 pr-4 py-3 rounded-lg bg-gray-800 text-white border border-gray-700 focus:outline-none focus:border-blue-500"
                />
              </div>
              <button
                type="submit"
                disabled={loading}
                className="px-8 py-3 bg-blue-500 hover:bg-blue-600 text-white rounded-lg font-medium transition-all flex items-center justify-center gap-2 disabled:opacity-50 disabled:cursor-not-allowed"
              >
                <Download className="w-5 h-5" />
                {loading ? 'Processing...' : 'Download'}
              </button>
            </div>
          </form>

          <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
            <div className="p-6 rounded-xl bg-gray-800/50">
              <h3 className="text-xl font-semibold text-white mb-2">Multiple Formats</h3>
              <p className="text-gray-400">Download in MP4, MP3, and more formats</p>
            </div>
            <div className="p-6 rounded-xl bg-gray-800/50">
              <h3 className="text-xl font-semibold text-white mb-2">High Quality</h3>
              <p className="text-gray-400">Support for HD and 4K quality videos</p>
            </div>
            <div className="p-6 rounded-xl bg-gray-800/50">
              <h3 className="text-xl font-semibold text-white mb-2">Fast & Free</h3>
              <p className="text-gray-400">Quick downloads with no registration needed</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}