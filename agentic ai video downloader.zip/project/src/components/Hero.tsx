import React from 'react';
import { ArrowRight } from 'lucide-react';

export default function Hero() {
  return (
    <div className="relative min-h-screen flex items-center justify-center overflow-hidden">
      <div className="absolute inset-0 bg-gradient-to-b from-blue-500/10 to-transparent" />
      <div className="relative z-10 text-center px-4 max-w-4xl mx-auto">
        <h1 className="text-5xl md:text-6xl font-bold text-white mb-6">
          Agentic AI Video Downloader<br />
          <span className="text-blue-400">Powered by Intelligence</span>
        </h1>
        <p className="text-gray-300 text-xl mb-8 max-w-2xl mx-auto">
          Experience the future of video downloading with our AI-powered platform.
          Fast, intelligent, and completely free.
        </p>
        <button className="bg-blue-500 hover:bg-blue-600 text-white px-8 py-3 rounded-lg font-medium flex items-center gap-2 mx-auto transition-all">
          Start Downloading <ArrowRight className="w-5 h-5" />
        </button>
      </div>
      <div className="absolute bottom-0 left-1/2 -translate-x-1/2 w-full max-w-4xl">
        <div className="relative w-full aspect-[16/9]">
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent" />
          <div className="absolute bottom-0 left-0 w-full h-32 bg-gradient-to-t from-black to-transparent" />
        </div>
      </div>
    </div>
  );
}