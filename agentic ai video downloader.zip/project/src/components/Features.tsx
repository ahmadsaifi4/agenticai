import React from 'react';
import { Shield, Zap, BarChart3, Clock, Lock, Share2 } from 'lucide-react';

const features = [
  {
    icon: Zap,
    title: 'Speed',
    description: 'Fast scaling for all smart contracts with our advanced infrastructure'
  },
  {
    icon: Shield,
    title: 'Security',
    description: 'Bank-level security to protect your assets and transactions'
  },
  {
    icon: BarChart3,
    title: 'Governance',
    description: 'Direct control over chain-level parameters'
  },
  {
    icon: Clock,
    title: 'Agency',
    description: 'Complete control over your blockchain deployment'
  },
  {
    icon: Lock,
    title: 'Reliability',
    description: 'Enterprise-grade uptime and performance guarantees'
  },
  {
    icon: Share2,
    title: 'Interoperability',
    description: 'Seamless integration with existing blockchain networks'
  }
];

export default function Features() {
  return (
    <div className="py-24 bg-black">
      <div className="max-w-7xl mx-auto px-4">
        <h2 className="text-3xl md:text-4xl font-bold text-center text-white mb-16">
          Powerful new features for<br />solving challenges
        </h2>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {features.map((feature, index) => (
            <div key={index} className="p-6 rounded-xl bg-gray-900/50 backdrop-blur-sm hover:bg-gray-800/50 transition-all">
              <feature.icon className="w-12 h-12 text-blue-400 mb-4" />
              <h3 className="text-xl font-semibold text-white mb-2">{feature.title}</h3>
              <p className="text-gray-400">{feature.description}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}