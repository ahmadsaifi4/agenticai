import React from 'react';

export default function Stats() {
  return (
    <div className="py-24 bg-black">
      <div className="max-w-7xl mx-auto px-4">
        <div className="bg-gray-900/50 backdrop-blur-sm rounded-2xl p-12">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 text-center">
            <div>
              <div className="text-4xl font-bold text-blue-400 mb-2">1.8M+</div>
              <div className="text-gray-400">Active developers</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-blue-400 mb-2">500K+</div>
              <div className="text-gray-400">Smart contracts deployed</div>
            </div>
            <div>
              <div className="text-4xl font-bold text-blue-400 mb-2">99.9%</div>
              <div className="text-gray-400">Uptime guaranteed</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}