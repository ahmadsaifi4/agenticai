import React from 'react';
import { VideoMetadata as VideoMetadataType } from '../../types/video';

interface VideoMetadataProps {
  metadata: VideoMetadataType;
}

export default function VideoMetadata({ metadata }: VideoMetadataProps) {
  return (
    <div className="flex gap-4 items-start mt-6 p-4 rounded-lg bg-gray-800/50">
      <img
        src={metadata.thumbnail}
        alt={metadata.title}
        className="w-48 rounded-lg"
      />
      <div>
        <h3 className="text-xl font-semibold text-white mb-2">{metadata.title}</h3>
        <p className="text-gray-400">Duration: {metadata.duration}</p>
      </div>
    </div>
  );
}