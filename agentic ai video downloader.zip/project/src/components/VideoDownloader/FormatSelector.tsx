import React from 'react';
import { VideoFormat } from '../../types/video';

interface FormatSelectorProps {
  formats: VideoFormat[];
  selectedFormat: string;
  onFormatChange: (format: string) => void;
}

export default function FormatSelector({ formats, selectedFormat, onFormatChange }: FormatSelectorProps) {
  return (
    <div className="grid grid-cols-2 gap-4 mt-4">
      {formats.map((format, index) => (
        <button
          key={index}
          onClick={() => onFormatChange(format.format)}
          className={`p-4 rounded-lg border ${
            selectedFormat === format.format
              ? 'border-blue-500 bg-blue-500/10 text-blue-400'
              : 'border-gray-700 hover:border-blue-500/50'
          } transition-all`}
        >
          <div className="font-medium">{format.format.toUpperCase()}</div>
          <div className="text-sm text-gray-400">{format.quality}</div>
          <div className="text-sm text-gray-400">{format.size}</div>
        </button>
      ))}
    </div>
  );
}